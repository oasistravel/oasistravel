
import React from 'react';

export default function AddReservation() {
  return (
    <div className="p-4">
      <h2>➕ إضافة حجز</h2><p>نموذج حجز سيتم إضافته هنا</p>
    </div>
  );
}
