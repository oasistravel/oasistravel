
import React from 'react';

export default function Companies() {
  return (
    <div className="p-4">
      <h2>🏢 إدارة الشركات</h2><p>قائمة الشركات هنا</p>
    </div>
  );
}
