
import React from 'react';

export default function CompanyReport() {
  return (
    <div className="p-4">
      <h2>📊 تقرير الشركات</h2><p>شارت أو جدول التقرير</p>
    </div>
  );
}
