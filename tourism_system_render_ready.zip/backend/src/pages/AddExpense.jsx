
import React from 'react';

export default function AddExpense() {
  return (
    <div className="p-4">
      <h2>💵 إضافة مصروف</h2><p>نموذج لإدخال مصروف</p>
    </div>
  );
}
