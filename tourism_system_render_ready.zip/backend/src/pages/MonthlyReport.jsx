
import React from 'react';

export default function MonthlyReport() {
  return (
    <div className="p-4">
      <h2>📅 التقرير الشهري</h2><p>ملخص شهري مالي</p>
    </div>
  );
}
