
import React from 'react';

export default function FinanceReport() {
  return (
    <div className="p-4">
      <h2>📆 تقرير الحسابات اليومية</h2><p>الإيرادات والمصروفات</p>
    </div>
  );
}
