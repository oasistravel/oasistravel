
import React from 'react';

export default function HiaceChart() {
  return (
    <div className="p-4">
      <h2>🚌 شارت هاي اس</h2><p>مقاعد الحجز</p>
    </div>
  );
}
