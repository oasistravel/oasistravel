
import React from 'react';

export default function InvoiceReport() {
  return (
    <div className="p-4">
      <h2>📋 تقرير الفواتير</h2><p>جدول الفواتير هنا</p>
    </div>
  );
}
