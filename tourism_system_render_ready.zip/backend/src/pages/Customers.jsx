
import React from 'react';

export default function Customers() {
  return (
    <div className="p-4">
      <h2>👥 إدارة العملاء</h2><p>قائمة وبحث وتعديل العملاء</p>
    </div>
  );
}
