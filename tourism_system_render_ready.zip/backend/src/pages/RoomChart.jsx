
import React from 'react';

export default function RoomChart() {
  return (
    <div className="p-4">
      <h2>🏨 شارت الغرف</h2><p>الغرف المتاحة والمحجوزة</p>
    </div>
  );
}
