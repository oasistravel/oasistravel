
import React from 'react';

export default function HR() {
  return (
    <div className="p-4">
      <h2>🧑‍💼 نظام الموارد البشرية</h2><p>موظفين وحضور ورواتب</p>
    </div>
  );
}
